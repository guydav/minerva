#!/bin/sh
sudo -H easy_install pip
sudo -H pip install --upgrade pip
sudo -H pip install --upgrade ipython
sudo -H pip install --upgrade jupyter

sudo -H pip install --upgrade tabulate
sudo -H pip install --upgrade numpy
sudo -H pip install --upgrade scipy
sudo -H pip install --upgrade matplotlib
sudo -H pip install --upgrade sklearn
